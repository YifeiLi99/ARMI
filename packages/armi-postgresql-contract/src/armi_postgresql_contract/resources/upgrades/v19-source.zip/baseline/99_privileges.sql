-- Current ARMI role grants. Table-level DML only; column-level writes are forbidden.

GRANT USAGE ON SCHEMA armi TO armi_admin;
GRANT USAGE ON SCHEMA armi TO armi_migrator;
GRANT USAGE ON SCHEMA armi TO armi_runtime;
GRANT USAGE ON SCHEMA armi_extensions TO armi_owner;
GRANT USAGE ON SCHEMA armi_extensions TO armi_migrator;
GRANT USAGE ON SCHEMA armi_extensions TO armi_runtime;
GRANT USAGE ON SCHEMA armi_extensions TO armi_admin;

GRANT SELECT ON TABLE armi.accepted_experiences TO armi_admin;
GRANT SELECT ON TABLE armi.accepted_experiences TO armi_runtime;
GRANT SELECT ON TABLE armi.action_intent_revisions TO armi_admin;
GRANT SELECT ON TABLE armi.action_intent_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.action_intents TO armi_admin;
GRANT SELECT ON TABLE armi.action_intents TO armi_runtime;
GRANT SELECT ON TABLE armi.activities TO armi_admin;
GRANT SELECT ON TABLE armi.activities TO armi_runtime;
GRANT SELECT ON TABLE armi.activity_decisions TO armi_admin;
GRANT SELECT ON TABLE armi.activity_decisions TO armi_runtime;
GRANT SELECT ON TABLE armi.activity_revisions TO armi_admin;
GRANT SELECT ON TABLE armi.activity_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.alembic_version TO armi_admin;
GRANT SELECT ON TABLE armi.alembic_version TO armi_migrator;
GRANT SELECT ON TABLE armi.alembic_version TO armi_runtime;
GRANT SELECT ON TABLE armi.artifact_object_deletion_attempts, armi.artifact_object_deletions, armi.artifact_objects, armi.artifact_publications, armi.artifacts TO armi_admin;
GRANT SELECT ON TABLE armi.artifact_object_deletion_attempts, armi.artifact_object_deletions, armi.artifact_objects, armi.artifact_publications, armi.artifacts TO armi_runtime;
GRANT SELECT ON TABLE armi.audit_events TO armi_admin;
GRANT SELECT ON TABLE armi.audit_events TO armi_runtime;
GRANT SELECT ON TABLE armi.capabilities TO armi_admin;
GRANT SELECT ON TABLE armi.capabilities TO armi_runtime;






GRANT SELECT ON TABLE armi.codex_result_sources TO armi_runtime;
GRANT SELECT ON TABLE armi.codex_task_sources TO armi_runtime;
GRANT SELECT ON TABLE armi.codex_verification_results TO armi_runtime;
GRANT SELECT ON TABLE armi.codex_verification_results TO armi_admin;
GRANT SELECT ON TABLE armi.cognition_maintenance_batch_sources TO armi_admin;
GRANT SELECT ON TABLE armi.cognition_maintenance_batch_sources TO armi_runtime;
GRANT SELECT ON TABLE armi.cognition_maintenance_batches TO armi_admin;
GRANT SELECT ON TABLE armi.cognition_maintenance_batches TO armi_runtime;
GRANT SELECT ON TABLE armi.cognition_maintenance_cursors TO armi_admin;
GRANT SELECT ON TABLE armi.cognition_maintenance_cursors TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_candidate_applications TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_candidate_applications TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_candidate_basis_links TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_candidate_basis_links TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_candidate_validation_items TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_candidate_validation_items TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_candidate_validations TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_candidate_validations TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_context_items TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_context_items TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_context_dependencies TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_context_dependencies TO armi_runtime;
GRANT SELECT ON TABLE armi.cognitive_episodes TO armi_admin;
GRANT SELECT ON TABLE armi.cognitive_episodes TO armi_runtime;
GRANT SELECT ON TABLE armi.context_embedding_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.context_embedding_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.context_embedding_coverage TO armi_admin;
GRANT SELECT ON TABLE armi.context_embedding_coverage TO armi_runtime;
GRANT SELECT ON TABLE armi.context_embedding_projections TO armi_admin;
GRANT SELECT ON TABLE armi.context_embedding_projections TO armi_runtime;
GRANT SELECT ON TABLE armi.context_embedding_source_sets TO armi_admin;
GRANT SELECT ON TABLE armi.context_embedding_source_sets TO armi_runtime;
GRANT SELECT ON TABLE armi.context_model_cache_hit_ratios TO armi_admin;
GRANT SELECT ON TABLE armi.context_model_cache_hit_ratios TO armi_runtime;
GRANT SELECT ON TABLE armi.creator_exports TO armi_runtime;
GRANT SELECT ON TABLE armi.managed_data_snapshot_parties TO armi_admin;
GRANT SELECT ON TABLE armi.managed_data_snapshot_parties TO armi_runtime;
GRANT SELECT ON TABLE armi.managed_data_snapshots TO armi_admin;
GRANT SELECT ON TABLE armi.managed_data_snapshots TO armi_runtime;
GRANT SELECT ON TABLE armi.data_rights_identity_keys TO armi_runtime;
GRANT SELECT ON TABLE armi.data_rights_order_items TO armi_runtime;
GRANT SELECT ON TABLE armi.data_rights_orders TO armi_runtime;
GRANT SELECT ON TABLE armi.data_rights_party_fences TO armi_admin;
GRANT SELECT ON TABLE armi.data_rights_party_fences TO armi_runtime;
GRANT SELECT ON TABLE armi.data_rights_order_retry_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.data_rights_order_retry_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.deployment_environments TO armi_admin;
GRANT SELECT ON TABLE armi.deployment_environments TO armi_runtime;
GRANT SELECT ON TABLE armi.dialogue_decisions TO armi_admin;
GRANT SELECT ON TABLE armi.dialogue_decisions TO armi_runtime;
GRANT SELECT ON TABLE armi.durable_work TO armi_admin;
GRANT SELECT ON TABLE armi.durable_work TO armi_runtime;
GRANT SELECT ON TABLE armi.effect_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.effect_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.effect_observations TO armi_admin;
GRANT SELECT ON TABLE armi.effect_observations TO armi_runtime;
GRANT SELECT ON TABLE armi.effect_outbox_items TO armi_admin;
GRANT SELECT ON TABLE armi.effect_outbox_items TO armi_runtime;
GRANT SELECT ON TABLE armi.effects TO armi_admin;
GRANT SELECT ON TABLE armi.effects TO armi_runtime;
GRANT SELECT ON TABLE armi.exact_life_query_intents TO armi_runtime;
GRANT SELECT ON TABLE armi.experience_evidence_links TO armi_admin;
GRANT SELECT ON TABLE armi.experience_evidence_links TO armi_runtime;
GRANT SELECT ON TABLE armi.external_channel_bindings TO armi_admin;
GRANT SELECT ON TABLE armi.external_channel_bindings TO armi_runtime;
GRANT SELECT ON TABLE armi.external_content_recognition_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.external_content_recognition_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.external_evidence TO armi_admin;
GRANT SELECT ON TABLE armi.external_evidence TO armi_runtime;
GRANT SELECT ON TABLE armi.external_message_parts TO armi_admin;
GRANT SELECT ON TABLE armi.external_message_parts TO armi_runtime;
GRANT SELECT ON TABLE armi.interaction_scenes TO armi_admin;
GRANT SELECT ON TABLE armi.interaction_scenes TO armi_runtime;
GRANT SELECT ON TABLE armi.life_generations TO armi_admin;
GRANT SELECT ON TABLE armi.life_generations TO armi_runtime;
GRANT SELECT ON TABLE armi.life_material_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.life_materials TO armi_runtime;
GRANT SELECT ON TABLE armi.live_vision_observation_frames TO armi_admin;
GRANT SELECT ON TABLE armi.live_vision_observation_frames TO armi_runtime;
GRANT SELECT ON TABLE armi.live_vision_observations TO armi_admin;
GRANT SELECT ON TABLE armi.live_vision_observations TO armi_runtime;
GRANT SELECT ON TABLE armi.live_vision_sessions TO armi_admin;
GRANT SELECT ON TABLE armi.live_vision_sessions TO armi_runtime;
GRANT SELECT ON TABLE armi.live_voice_playback_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.live_voice_playback_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.live_voice_provider_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.live_voice_provider_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.live_voice_sessions TO armi_admin;
GRANT SELECT ON TABLE armi.live_voice_sessions TO armi_runtime;
GRANT SELECT ON TABLE armi.live_voice_text_fragments TO armi_admin;
GRANT SELECT ON TABLE armi.live_voice_text_fragments TO armi_runtime;
GRANT SELECT ON TABLE armi.live_voice_turns TO armi_admin;
GRANT SELECT ON TABLE armi.live_voice_turns TO armi_runtime;
GRANT SELECT ON TABLE armi.local_inbox_deliveries TO armi_admin;
GRANT SELECT ON TABLE armi.local_inbox_deliveries TO armi_runtime;
GRANT SELECT ON TABLE armi.maintenance_phase_results TO armi_admin;
GRANT SELECT ON TABLE armi.maintenance_phase_results TO armi_runtime;
GRANT SELECT ON TABLE armi.maintenance_session_revisions TO armi_admin;
GRANT SELECT ON TABLE armi.maintenance_session_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.maintenance_sessions TO armi_admin;
GRANT SELECT ON TABLE armi.maintenance_sessions TO armi_runtime;
GRANT SELECT ON TABLE armi.memory_relations TO armi_runtime;
GRANT SELECT ON TABLE armi.mood_appraisal_events TO armi_admin;
GRANT SELECT ON TABLE armi.mood_appraisal_events TO armi_runtime;
GRANT SELECT ON TABLE armi.mood_heads TO armi_admin;
GRANT SELECT ON TABLE armi.mood_heads TO armi_runtime;
GRANT SELECT ON TABLE armi.mood_revisions TO armi_admin;
GRANT SELECT ON TABLE armi.mood_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.observation_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.observation_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.observation_tool_calls TO armi_admin;
GRANT SELECT ON TABLE armi.observation_tool_calls TO armi_runtime;
GRANT SELECT ON TABLE armi.opportunities TO armi_admin;
GRANT SELECT ON TABLE armi.opportunities TO armi_runtime;
GRANT SELECT ON TABLE armi.parties TO armi_admin;
GRANT SELECT ON TABLE armi.parties TO armi_runtime;
GRANT SELECT ON TABLE armi.party_input_interactions TO armi_admin;
GRANT SELECT ON TABLE armi.system_notifications TO armi_admin;
GRANT SELECT, INSERT ON TABLE armi.system_notifications TO armi_runtime;
GRANT SELECT ON TABLE armi.party_input_interactions TO armi_runtime;




GRANT SELECT ON TABLE armi.prompt_documents TO armi_admin;
GRANT SELECT ON TABLE armi.prompt_documents TO armi_runtime;
GRANT SELECT ON TABLE armi.prompt_revisions TO armi_admin;
GRANT SELECT ON TABLE armi.prompt_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.relationship_experience_links TO armi_runtime;
GRANT SELECT ON TABLE armi.relationship_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.relationships TO armi_runtime;
GRANT SELECT ON TABLE armi.runtime_bundle_activations TO armi_admin;
GRANT SELECT ON TABLE armi.runtime_bundle_activations TO armi_runtime;
GRANT SELECT ON TABLE armi.runtime_instances TO armi_admin;
GRANT SELECT ON TABLE armi.runtime_instances TO armi_runtime;
GRANT SELECT ON TABLE armi.runtime_recovery_metrics TO armi_admin;
GRANT SELECT ON TABLE armi.runtime_recovery_metrics TO armi_runtime;
GRANT SELECT ON TABLE armi.runtime_recovery_runs TO armi_admin;
GRANT SELECT ON TABLE armi.runtime_recovery_runs TO armi_runtime;
GRANT SELECT ON TABLE armi.scene_participants TO armi_admin;
GRANT SELECT ON TABLE armi.scene_participants TO armi_runtime;
GRANT SELECT ON TABLE armi.scene_timeline_items TO armi_admin;
GRANT SELECT ON TABLE armi.scene_timeline_items TO armi_runtime;
GRANT SELECT ON TABLE armi.schema_baseline_identity TO armi_admin;
GRANT SELECT ON TABLE armi.schema_baseline_identity TO armi_migrator;
GRANT SELECT ON TABLE armi.schema_baseline_identity TO armi_runtime;
GRANT SELECT ON TABLE armi.sleep_decisions TO armi_admin;
GRANT SELECT ON TABLE armi.sleep_decisions TO armi_runtime;
GRANT SELECT ON TABLE armi.subject_commits TO armi_admin;
GRANT SELECT ON TABLE armi.subject_commits TO armi_runtime;
GRANT SELECT ON TABLE armi.subject_component_heads TO armi_admin;
GRANT SELECT ON TABLE armi.subject_component_heads TO armi_runtime;
GRANT SELECT ON TABLE armi.subject_component_revisions TO armi_admin;
GRANT SELECT ON TABLE armi.subject_component_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.subjective_memories TO armi_runtime;
GRANT SELECT ON TABLE armi.subjective_memory_revisions TO armi_runtime;
GRANT SELECT ON TABLE armi.subjects TO armi_admin;
GRANT SELECT ON TABLE armi.subjects TO armi_runtime;
GRANT SELECT ON TABLE armi.visual_recognition_attempts TO armi_admin;
GRANT SELECT ON TABLE armi.visual_recognition_attempts TO armi_runtime;
GRANT SELECT ON TABLE armi.web_evidence_sources TO armi_admin;
GRANT SELECT ON TABLE armi.web_evidence_sources TO armi_runtime;
GRANT SELECT ON TABLE armi.web_observation_requests TO armi_admin;
GRANT SELECT ON TABLE armi.web_observation_requests TO armi_runtime;
GRANT SELECT ON TABLE armi.web_research_intents TO armi_admin;
GRANT SELECT ON TABLE armi.web_research_intents TO armi_runtime;

GRANT DELETE ON TABLE armi.artifacts, armi.audit_events, armi.dialogue_decisions, armi.external_content_recognition_attempts, armi.external_evidence, armi.external_message_parts, armi.local_inbox_deliveries, armi.opportunities, armi.party_input_interactions, armi.scene_timeline_items TO armi_admin;
GRANT INSERT ON TABLE armi.deployment_environments, armi.durable_work, armi.effect_observations, armi.mood_revisions, armi.subject_component_revisions TO armi_admin;
GRANT UPDATE ON TABLE armi.durable_work, armi.effect_outbox_items, armi.effects, armi.mood_heads, armi.runtime_instances, armi.subject_component_heads, armi.subjects TO armi_admin;
GRANT INSERT ON TABLE armi.artifact_object_deletion_attempts, armi.artifact_object_deletions, armi.artifact_objects, armi.artifact_publications, armi.artifacts TO armi_admin;
GRANT UPDATE ON TABLE armi.artifact_object_deletions, armi.artifact_objects, armi.artifact_publications, armi.artifacts TO armi_admin;
GRANT DELETE ON TABLE armi.context_embedding_projections TO armi_runtime;


GRANT INSERT ON TABLE armi.artifact_object_deletion_attempts, armi.artifact_object_deletions, armi.artifact_objects, armi.artifact_publications TO armi_runtime;
GRANT INSERT ON TABLE armi.data_rights_order_retry_attempts TO armi_runtime;
GRANT INSERT ON TABLE armi.data_rights_identity_keys TO armi_runtime;
GRANT UPDATE ON TABLE armi.artifact_object_deletions, armi.artifact_objects, armi.artifact_publications TO armi_runtime;
GRANT UPDATE ON TABLE armi.data_rights_party_fences TO armi_runtime;
GRANT INSERT, UPDATE ON TABLE armi.context_embedding_source_sets TO armi_runtime;
GRANT UPDATE ON TABLE armi.accepted_experiences, armi.activity_revisions, armi.life_material_revisions, armi.mood_appraisal_events, armi.relationship_revisions, armi.subject_component_revisions, armi.subjective_memory_revisions TO armi_runtime;
GRANT INSERT ON TABLE armi.managed_data_snapshot_parties, armi.managed_data_snapshots TO armi_runtime;
GRANT UPDATE ON TABLE armi.managed_data_snapshots TO armi_runtime;
GRANT USAGE, SELECT ON SEQUENCE armi.accepted_experiences_acceptance_ordinal_seq TO armi_runtime;


GRANT SELECT ON TABLE armi.context_embedding_failures TO armi_admin;
GRANT SELECT, INSERT ON TABLE armi.context_embedding_failures TO armi_runtime;
GRANT INSERT ON TABLE armi.accepted_experiences, armi.action_intent_revisions, armi.action_intents, armi.activities, armi.activity_decisions, armi.activity_revisions, armi.artifacts, armi.audit_events, armi.codex_result_sources, armi.codex_task_sources, armi.codex_verification_results, armi.cognition_maintenance_batch_sources, armi.cognition_maintenance_batches, armi.cognition_maintenance_cursors, armi.cognitive_attempts, armi.cognitive_candidate_applications, armi.cognitive_candidate_basis_links, armi.cognitive_candidate_validation_items, armi.cognitive_candidate_validations, armi.cognitive_context_dependencies, armi.cognitive_context_items, armi.cognitive_episodes, armi.context_embedding_attempts, armi.context_embedding_coverage, armi.context_embedding_projections, armi.creator_exports, armi.data_rights_order_items, armi.data_rights_orders, armi.data_rights_party_fences, armi.dialogue_decisions, armi.durable_work, armi.effect_attempts, armi.effect_observations, armi.effect_outbox_items, armi.effects, armi.exact_life_query_intents, armi.experience_evidence_links, armi.external_channel_bindings, armi.external_content_recognition_attempts, armi.external_evidence, armi.external_message_parts, armi.interaction_scenes, armi.life_generations, armi.life_material_revisions, armi.life_materials, armi.live_vision_observation_frames, armi.live_vision_observations, armi.live_vision_sessions, armi.live_voice_playback_attempts, armi.live_voice_provider_attempts, armi.live_voice_sessions, armi.live_voice_text_fragments, armi.live_voice_turns, armi.local_inbox_deliveries, armi.maintenance_phase_results, armi.maintenance_session_revisions, armi.maintenance_sessions, armi.memory_relations, armi.mood_appraisal_events, armi.mood_heads, armi.mood_revisions, armi.observation_attempts, armi.observation_tool_calls, armi.opportunities, armi.parties, armi.party_input_interactions, armi.prompt_documents, armi.prompt_revisions, armi.relationship_experience_links, armi.relationship_revisions, armi.relationships, armi.runtime_bundle_activations, armi.runtime_instances, armi.runtime_recovery_metrics, armi.runtime_recovery_runs, armi.scene_participants, armi.scene_timeline_items, armi.sleep_decisions, armi.subject_commits, armi.subject_component_heads, armi.subject_component_revisions, armi.subjective_memories, armi.subjective_memory_revisions, armi.subjects, armi.visual_recognition_attempts, armi.web_evidence_sources, armi.web_observation_requests, armi.web_research_intents TO armi_runtime;
GRANT UPDATE ON TABLE armi.action_intent_revisions, armi.action_intents, armi.activities, armi.activity_decisions, armi.artifacts, armi.cognition_maintenance_batch_sources, armi.cognition_maintenance_batches, armi.cognition_maintenance_cursors, armi.cognitive_attempts, armi.cognitive_episodes, armi.context_embedding_attempts, armi.context_embedding_coverage, armi.creator_exports, armi.data_rights_order_items, armi.data_rights_orders, armi.dialogue_decisions, armi.durable_work, armi.effect_attempts, armi.effect_outbox_items, armi.effects, armi.exact_life_query_intents, armi.external_channel_bindings, armi.external_content_recognition_attempts, armi.external_evidence, armi.external_message_parts, armi.interaction_scenes, armi.life_materials, armi.live_vision_observation_frames, armi.live_vision_observations, armi.live_vision_sessions, armi.live_voice_playback_attempts, armi.live_voice_provider_attempts, armi.live_voice_sessions, armi.live_voice_text_fragments, armi.live_voice_turns, armi.local_inbox_deliveries, armi.maintenance_sessions, armi.mood_heads, armi.observation_attempts, armi.opportunities, armi.parties, armi.party_input_interactions, armi.prompt_documents, armi.relationships, armi.runtime_instances, armi.runtime_recovery_metrics, armi.runtime_recovery_runs, armi.scene_participants, armi.subject_component_heads, armi.subjective_memories, armi.subjects, armi.visual_recognition_attempts, armi.web_observation_requests, armi.web_research_intents TO armi_runtime;

GRANT DELETE ON TABLE armi.accepted_experiences TO armi_admin;

GRANT INSERT ON TABLE armi.accepted_experiences TO armi_admin;

GRANT UPDATE ON TABLE armi.accepted_experiences TO armi_admin;

GRANT DELETE ON TABLE armi.action_intent_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.action_intent_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.action_intent_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.action_intents TO armi_admin;

GRANT INSERT ON TABLE armi.action_intents TO armi_admin;

GRANT UPDATE ON TABLE armi.action_intents TO armi_admin;

GRANT DELETE ON TABLE armi.activities TO armi_admin;

GRANT INSERT ON TABLE armi.activities TO armi_admin;

GRANT UPDATE ON TABLE armi.activities TO armi_admin;

GRANT DELETE ON TABLE armi.activity_decisions TO armi_admin;

GRANT INSERT ON TABLE armi.activity_decisions TO armi_admin;

GRANT UPDATE ON TABLE armi.activity_decisions TO armi_admin;

GRANT DELETE ON TABLE armi.activity_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.activity_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.activity_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.admin_data_changes TO armi_admin;

GRANT SELECT ON TABLE armi.admin_data_changes TO armi_admin;

GRANT DELETE ON TABLE armi.codex_result_sources TO armi_admin;

GRANT INSERT ON TABLE armi.codex_result_sources TO armi_admin;

GRANT SELECT ON TABLE armi.codex_result_sources TO armi_admin;

GRANT UPDATE ON TABLE armi.codex_result_sources TO armi_admin;

GRANT DELETE ON TABLE armi.codex_task_sources TO armi_admin;

GRANT INSERT ON TABLE armi.codex_task_sources TO armi_admin;

GRANT SELECT ON TABLE armi.codex_task_sources TO armi_admin;

GRANT UPDATE ON TABLE armi.codex_task_sources TO armi_admin;

GRANT DELETE ON TABLE armi.cognition_maintenance_batch_sources TO armi_admin;

GRANT INSERT ON TABLE armi.cognition_maintenance_batch_sources TO armi_admin;

GRANT UPDATE ON TABLE armi.cognition_maintenance_batch_sources TO armi_admin;

GRANT DELETE ON TABLE armi.cognition_maintenance_batches TO armi_admin;

GRANT INSERT ON TABLE armi.cognition_maintenance_batches TO armi_admin;

GRANT UPDATE ON TABLE armi.cognition_maintenance_batches TO armi_admin;

GRANT DELETE ON TABLE armi.cognition_maintenance_cursors TO armi_admin;

GRANT INSERT ON TABLE armi.cognition_maintenance_cursors TO armi_admin;

GRANT UPDATE ON TABLE armi.cognition_maintenance_cursors TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_attempts TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_attempts TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_attempts TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_candidate_applications TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_candidate_applications TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_candidate_applications TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_candidate_basis_links TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_candidate_basis_links TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_candidate_basis_links TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_candidate_validation_items TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_candidate_validation_items TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_candidate_validation_items TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_candidate_validations TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_candidate_validations TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_candidate_validations TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_context_dependencies TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_context_dependencies TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_context_dependencies TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_context_items TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_context_items TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_context_items TO armi_admin;

GRANT DELETE ON TABLE armi.cognitive_episodes TO armi_admin;

GRANT INSERT ON TABLE armi.cognitive_episodes TO armi_admin;

GRANT UPDATE ON TABLE armi.cognitive_episodes TO armi_admin;

GRANT DELETE ON TABLE armi.context_embedding_attempts TO armi_admin;

GRANT INSERT ON TABLE armi.context_embedding_attempts TO armi_admin;

GRANT UPDATE ON TABLE armi.context_embedding_attempts TO armi_admin;

GRANT DELETE ON TABLE armi.context_embedding_coverage TO armi_admin;

GRANT INSERT ON TABLE armi.context_embedding_coverage TO armi_admin;

GRANT UPDATE ON TABLE armi.context_embedding_coverage TO armi_admin;

GRANT DELETE ON TABLE armi.context_embedding_failures TO armi_admin;

GRANT INSERT ON TABLE armi.context_embedding_failures TO armi_admin;

GRANT UPDATE ON TABLE armi.context_embedding_failures TO armi_admin;

GRANT DELETE ON TABLE armi.context_embedding_projections TO armi_admin;

GRANT INSERT ON TABLE armi.context_embedding_projections TO armi_admin;

GRANT UPDATE ON TABLE armi.context_embedding_projections TO armi_admin;

GRANT DELETE ON TABLE armi.context_embedding_source_sets TO armi_admin;

GRANT INSERT ON TABLE armi.context_embedding_source_sets TO armi_admin;

GRANT UPDATE ON TABLE armi.context_embedding_source_sets TO armi_admin;

GRANT SELECT ON TABLE armi.creator_exports TO armi_admin;

GRANT SELECT ON TABLE armi.data_rights_identity_keys TO armi_admin;

GRANT SELECT ON TABLE armi.data_rights_order_items TO armi_admin;

GRANT SELECT ON TABLE armi.data_rights_orders TO armi_admin;

GRANT INSERT ON TABLE armi.dialogue_decisions TO armi_admin;

GRANT UPDATE ON TABLE armi.dialogue_decisions TO armi_admin;

GRANT DELETE ON TABLE armi.durable_work TO armi_admin;

GRANT DELETE ON TABLE armi.exact_life_query_intents TO armi_admin;

GRANT INSERT ON TABLE armi.exact_life_query_intents TO armi_admin;

GRANT SELECT ON TABLE armi.exact_life_query_intents TO armi_admin;

GRANT UPDATE ON TABLE armi.exact_life_query_intents TO armi_admin;

GRANT DELETE ON TABLE armi.experience_evidence_links TO armi_admin;

GRANT INSERT ON TABLE armi.experience_evidence_links TO armi_admin;

GRANT UPDATE ON TABLE armi.experience_evidence_links TO armi_admin;

GRANT INSERT ON TABLE armi.external_content_recognition_attempts TO armi_admin;

GRANT UPDATE ON TABLE armi.external_content_recognition_attempts TO armi_admin;

GRANT INSERT ON TABLE armi.external_evidence TO armi_admin;

GRANT UPDATE ON TABLE armi.external_evidence TO armi_admin;

GRANT INSERT ON TABLE armi.external_message_parts TO armi_admin;

GRANT UPDATE ON TABLE armi.external_message_parts TO armi_admin;

GRANT DELETE ON TABLE armi.interaction_scenes TO armi_admin;

GRANT INSERT ON TABLE armi.interaction_scenes TO armi_admin;

GRANT UPDATE ON TABLE armi.interaction_scenes TO armi_admin;

GRANT DELETE ON TABLE armi.life_material_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.life_material_revisions TO armi_admin;

GRANT SELECT ON TABLE armi.life_material_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.life_material_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.life_materials TO armi_admin;

GRANT INSERT ON TABLE armi.life_materials TO armi_admin;

GRANT SELECT ON TABLE armi.life_materials TO armi_admin;

GRANT UPDATE ON TABLE armi.life_materials TO armi_admin;

GRANT DELETE ON TABLE armi.live_vision_observation_frames TO armi_admin;

GRANT INSERT ON TABLE armi.live_vision_observation_frames TO armi_admin;

GRANT UPDATE ON TABLE armi.live_vision_observation_frames TO armi_admin;

GRANT DELETE ON TABLE armi.live_vision_observations TO armi_admin;

GRANT INSERT ON TABLE armi.live_vision_observations TO armi_admin;

GRANT UPDATE ON TABLE armi.live_vision_observations TO armi_admin;

GRANT DELETE ON TABLE armi.live_vision_sessions TO armi_admin;

GRANT INSERT ON TABLE armi.live_vision_sessions TO armi_admin;

GRANT UPDATE ON TABLE armi.live_vision_sessions TO armi_admin;

GRANT DELETE ON TABLE armi.live_voice_playback_attempts TO armi_admin;

GRANT INSERT ON TABLE armi.live_voice_playback_attempts TO armi_admin;

GRANT UPDATE ON TABLE armi.live_voice_playback_attempts TO armi_admin;

GRANT DELETE ON TABLE armi.live_voice_provider_attempts TO armi_admin;

GRANT INSERT ON TABLE armi.live_voice_provider_attempts TO armi_admin;

GRANT UPDATE ON TABLE armi.live_voice_provider_attempts TO armi_admin;

GRANT DELETE ON TABLE armi.live_voice_sessions TO armi_admin;

GRANT INSERT ON TABLE armi.live_voice_sessions TO armi_admin;

GRANT UPDATE ON TABLE armi.live_voice_sessions TO armi_admin;

GRANT DELETE ON TABLE armi.live_voice_text_fragments TO armi_admin;

GRANT INSERT ON TABLE armi.live_voice_text_fragments TO armi_admin;

GRANT UPDATE ON TABLE armi.live_voice_text_fragments TO armi_admin;

GRANT DELETE ON TABLE armi.live_voice_turns TO armi_admin;

GRANT INSERT ON TABLE armi.live_voice_turns TO armi_admin;

GRANT UPDATE ON TABLE armi.live_voice_turns TO armi_admin;

GRANT DELETE ON TABLE armi.maintenance_phase_results TO armi_admin;

GRANT INSERT ON TABLE armi.maintenance_phase_results TO armi_admin;

GRANT UPDATE ON TABLE armi.maintenance_phase_results TO armi_admin;

GRANT DELETE ON TABLE armi.maintenance_session_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.maintenance_session_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.maintenance_session_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.maintenance_sessions TO armi_admin;

GRANT INSERT ON TABLE armi.maintenance_sessions TO armi_admin;

GRANT UPDATE ON TABLE armi.maintenance_sessions TO armi_admin;

GRANT DELETE ON TABLE armi.memory_relations TO armi_admin;

GRANT INSERT ON TABLE armi.memory_relations TO armi_admin;

GRANT SELECT ON TABLE armi.memory_relations TO armi_admin;

GRANT UPDATE ON TABLE armi.memory_relations TO armi_admin;

GRANT DELETE ON TABLE armi.mood_appraisal_events TO armi_admin;

GRANT INSERT ON TABLE armi.mood_appraisal_events TO armi_admin;

GRANT UPDATE ON TABLE armi.mood_appraisal_events TO armi_admin;

GRANT DELETE ON TABLE armi.mood_heads TO armi_admin;

GRANT INSERT ON TABLE armi.mood_heads TO armi_admin;

GRANT DELETE ON TABLE armi.mood_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.mood_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.observation_attempts TO armi_admin;

GRANT INSERT ON TABLE armi.observation_attempts TO armi_admin;

GRANT UPDATE ON TABLE armi.observation_attempts TO armi_admin;

GRANT DELETE ON TABLE armi.observation_tool_calls TO armi_admin;

GRANT INSERT ON TABLE armi.observation_tool_calls TO armi_admin;

GRANT UPDATE ON TABLE armi.observation_tool_calls TO armi_admin;

GRANT INSERT ON TABLE armi.opportunities TO armi_admin;

GRANT UPDATE ON TABLE armi.opportunities TO armi_admin;

GRANT INSERT ON TABLE armi.party_input_interactions TO armi_admin;

GRANT UPDATE ON TABLE armi.party_input_interactions TO armi_admin;

GRANT DELETE ON TABLE armi.prompt_documents TO armi_admin;

GRANT INSERT ON TABLE armi.prompt_documents TO armi_admin;

GRANT UPDATE ON TABLE armi.prompt_documents TO armi_admin;

GRANT DELETE ON TABLE armi.prompt_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.prompt_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.prompt_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.relationship_experience_links TO armi_admin;

GRANT INSERT ON TABLE armi.relationship_experience_links TO armi_admin;

GRANT SELECT ON TABLE armi.relationship_experience_links TO armi_admin;

GRANT UPDATE ON TABLE armi.relationship_experience_links TO armi_admin;

GRANT DELETE ON TABLE armi.relationship_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.relationship_revisions TO armi_admin;

GRANT SELECT ON TABLE armi.relationship_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.relationship_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.relationships TO armi_admin;

GRANT INSERT ON TABLE armi.relationships TO armi_admin;

GRANT SELECT ON TABLE armi.relationships TO armi_admin;

GRANT UPDATE ON TABLE armi.relationships TO armi_admin;

GRANT DELETE ON TABLE armi.runtime_recovery_metrics TO armi_admin;

GRANT INSERT ON TABLE armi.runtime_recovery_metrics TO armi_admin;

GRANT UPDATE ON TABLE armi.runtime_recovery_metrics TO armi_admin;

GRANT DELETE ON TABLE armi.runtime_recovery_runs TO armi_admin;

GRANT INSERT ON TABLE armi.runtime_recovery_runs TO armi_admin;

GRANT UPDATE ON TABLE armi.runtime_recovery_runs TO armi_admin;

GRANT INSERT ON TABLE armi.scene_timeline_items TO armi_admin;

GRANT UPDATE ON TABLE armi.scene_timeline_items TO armi_admin;

GRANT DELETE ON TABLE armi.sleep_decisions TO armi_admin;

GRANT INSERT ON TABLE armi.sleep_decisions TO armi_admin;

GRANT UPDATE ON TABLE armi.sleep_decisions TO armi_admin;

GRANT DELETE ON TABLE armi.subject_component_heads TO armi_admin;

GRANT INSERT ON TABLE armi.subject_component_heads TO armi_admin;

GRANT DELETE ON TABLE armi.subject_component_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.subject_component_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.subjective_memories TO armi_admin;

GRANT INSERT ON TABLE armi.subjective_memories TO armi_admin;

GRANT SELECT ON TABLE armi.subjective_memories TO armi_admin;

GRANT UPDATE ON TABLE armi.subjective_memories TO armi_admin;

GRANT DELETE ON TABLE armi.subjective_memory_revisions TO armi_admin;

GRANT INSERT ON TABLE armi.subjective_memory_revisions TO armi_admin;

GRANT SELECT ON TABLE armi.subjective_memory_revisions TO armi_admin;

GRANT UPDATE ON TABLE armi.subjective_memory_revisions TO armi_admin;

GRANT DELETE ON TABLE armi.visual_recognition_attempts TO armi_admin;

GRANT INSERT ON TABLE armi.visual_recognition_attempts TO armi_admin;

GRANT UPDATE ON TABLE armi.visual_recognition_attempts TO armi_admin;

GRANT DELETE ON TABLE armi.web_evidence_sources TO armi_admin;

GRANT INSERT ON TABLE armi.web_evidence_sources TO armi_admin;

GRANT UPDATE ON TABLE armi.web_evidence_sources TO armi_admin;

GRANT DELETE ON TABLE armi.web_observation_requests TO armi_admin;

GRANT INSERT ON TABLE armi.web_observation_requests TO armi_admin;

GRANT UPDATE ON TABLE armi.web_observation_requests TO armi_admin;

GRANT DELETE ON TABLE armi.web_research_intents TO armi_admin;

GRANT INSERT ON TABLE armi.web_research_intents TO armi_admin;

GRANT UPDATE ON TABLE armi.web_research_intents TO armi_admin;

GRANT SELECT ON TABLE armi.admin_data_changes TO armi_runtime;
